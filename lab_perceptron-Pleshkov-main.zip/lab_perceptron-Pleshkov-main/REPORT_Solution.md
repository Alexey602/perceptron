# Лабораторная работа по курсу "Искусственный интеллект"
# Многослойный персептрон

| Студент | *Плешков А.О.* |
|------|------|
| Группа  | *М8О-306Б-19* |
| Оценка 2 (PyTorch) | *X* |
| Проверил | Сошников Д.В. |

## Отчёт по работе

# MNIST:

![image](https://user-images.githubusercontent.com/66428811/165090413-4b11dff0-5d33-44de-b412-71d78f13522f.png)

# FashionMNIST:

![image](https://user-images.githubusercontent.com/66428811/165090806-bbafcd7b-b4d3-4632-a8d4-8682315cc809.png)

# CIFAR-10:

![image](https://user-images.githubusercontent.com/66428811/165091415-53298dd2-94fc-44ee-933a-9042f5c9fd7b.png)

# Персептрон на PyTorch:

```python

class PyTorchPerceptron(torch.nn.Module):
    def __init__(self, layers=[10], func=torch.nn.Sigmoid(), 
                 loss_func=torch.nn.functional.binary_cross_entropy_with_logits, 
                 epochs=10,show_status=False, learning_rate=0.05):
        super().__init__()
        self.layers=layers
        self.func=func
        self.epochs=epochs
        self.show_status=show_status
        self.learning_rate=learning_rate
        self.level=0
        self.loss_function=loss_func
    
    def status_print(self, msg, level=-1):
        if level == -1:
            level = self.level
        print("  "*level + msg)
        
    def fit(self, X, Y):
        self.create_net(X,Y)
        
        if self.show_status:
            self.level = 0
            self.status_print("Обучение сети:")
            self.level += 1
        
        self.train(X,Y)
        return self
        
    def create_net(self, X,Y):
        self.level=0
        layers_settings = self.layers.copy()
        layers_settings.insert(0, len(X[0]))
        layers_settings.append(len(np.unique(Y)))
        self.classes_count = layers_settings[-1]
        module_layers = []
        
        if self.show_status:
            self.status_print("Создание сети:")
            self.level += 1
            self.status_print("Количество скрытых слоев    : {}".format(len(layers_settings)-2))
            self.status_print("Количество входных нейронов : {}".format(layers_settings[0]))
            self.status_print("Koличество выходных нейронов: {}".format(layers_settings[-1]))
            self.status_print("Широты скрытых слоев        : {}".format(self.layers))
            self.level -= 1
        
        for i in range(len(layers_settings)-2):
            module_layers.append(torch.nn.Linear(layers_settings[i], layers_settings[i+1]))
            module_layers.append(self.func)
            
        module_layers.append(torch.nn.Linear(layers_settings[-2], layers_settings[-1]))
        self.net = torch.nn.Sequential(*module_layers)
        return self    

    def train(self, X, Y):
        val_x = torch.tensor(np.array(X).astype(np.float32))
        val_y = []
        for y in Y:
            val = np.zeros(self.classes_count)
            for i in range(10):
                val[i] = 1 if i == y else 0
            val_y.append(val.copy().astype(np.float32))
        dataset = torch.utils.data.TensorDataset(val_x,torch.tensor(val_y,dtype=torch.float32))
        dataloader = torch.utils.data.DataLoader(dataset,batch_size=16)
        optim = torch.optim.Adam(self.net.parameters(),lr=self.learning_rate)
        for epoch in range(1, self.epochs+1):
            for (x,y) in dataloader:
                z = self.net(x)
                loss = self.loss_function(z,y)
                optim.zero_grad()
                loss.backward()
                optim.step()
            acc = self.score(X,Y)
            if self.show_status:
                self.status_print("[Эпоха {} из {}] Потеря: {}, Точность: {}".format(epoch, self.epochs,loss,acc))
                
    def score(self, X, Y):
        val_x = torch.tensor(np.array(X).astype(np.float32))
        answer = self.net(val_x)
        results = [ np.argmax(v.detach().numpy()) for v in self.func(answer)]
        total_success = 0
        for res, y in zip(results, Y):
            if res == y:
                total_success += 1
        acc = total_success / len(Y)
        return acc
    def confusion_matrix(self, X, Y):
        val_x = torch.tensor(np.array(X).astype(np.float32))
        answer = self.net(val_x)
        results = [ np.argmax(v.detach().numpy()) for v in self.func(answer)]
        matrix = np.zeros((self.classes_count, self.classes_count), dtype=np.int32)
        for res, y in zip(results, Y):
            matrix[res][y] += 1
        return matrix
```

Получим ConfusionMatrix для наиболее удачных нейронных сетей:

![image](https://user-images.githubusercontent.com/66428811/165092203-2787a965-95a3-4707-a8ce-1e8b9908c3cd.png)
![image](https://user-images.githubusercontent.com/66428811/165092276-4b943ca1-c16f-4117-8e5e-eb4c176f5cf8.png)

![image](https://user-images.githubusercontent.com/66428811/165092448-070b7093-b999-45e3-ad4e-ea4308b7f7ce.png)
![image](https://user-images.githubusercontent.com/66428811/165092319-d393adb1-3b7b-4357-b9d0-7c58b95513d7.png)

Сравнение полученных показателей точности модели для различных гиперпараметров:

![image](https://user-images.githubusercontent.com/66428811/165092630-303c91ea-25dc-4456-91dc-7d17d531f8c2.png)

Вывод:

В ходе лабораторной работы удалось реализовать несколько простых нейросетей с использованием фреймворка для создания нейросетей - PyTorch. Нейросети были обучены и протестированы на разных датасетаx: MNIST, FashionMNIST и CIFAR-10.   
Результаты тестирования на датасетах MNIST и FashionMNIST довольно хорошие (вплость до 89%). К сожалению на датасете CIFAR-10 результаты довольно низкие, это связано с тем, что для классификации данного датасета нужно использовать сверточные слои.  
Так же стало понятно, что PyTorch уже содержит базовые наборы данных и конструкции для нейросетей, поэтому с помощью него можно быстро реализовать персептрон. Базовые датасеты можно быстро и легко научить распознавать с довольно высокой точностью.
